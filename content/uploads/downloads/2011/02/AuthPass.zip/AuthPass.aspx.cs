//	------Creates a form with the user's credientails and POSTs it to the Citrix Web Interface.------
//									------blog.rhysgoodwin.com------
using System;
using System.Net;
using System.Text;
using System.Web;

public partial class AuthPass: System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		FormContainer.InnerHtml = doLogin(Request.ServerVariables["AUTH_USER"],Request.ServerVariables["AUTH_PASSWORD"]);
	}


	private String doLogin(String strUser, String strPassword)
	{
		StringBuilder strForm = new StringBuilder();
		strForm.Append("<form name=\"CitrixForm\" action=\"https://citrix.corp.com/Citrix/XenApp/auth/login.aspx\" method=\"post\">");
		strForm.Append("<input type=\"hidden\" name=\"domain\" value=\"MyDomain\">");
		strForm.Append("<input type=\"hidden\" name=\"user\" value=\"{0}\">");
		strForm.Append("<input type=\"hidden\" name=\"password\" value=\"{1}\">");
		strForm.Append("<input type=\"hidden\" name=\"LoginType\" value=\"Explicit\">");
		strForm.Append("</form>");
		return String.Format(strForm.ToString(), strUser, strPassword);
	}	

}