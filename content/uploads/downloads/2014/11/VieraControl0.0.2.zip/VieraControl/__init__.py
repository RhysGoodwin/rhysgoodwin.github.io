"""<rst>
Panasonic Viera TV control Plug-in by Rhys Goodwin 

|

**Configuration**

You can find your TV's IP address in the network settings menu. Port Number is typically 55000

**Compatibility**

Not all commands work on all TVs. I've got a VT30 and some commands work. This plug-in was thrown together pretty quickly and I don't know how to write Python. 
Anyway it works for me and hopefully is some use to you too. 
Check out my blog. http://blog.rhysgoodwin.com

"""

import eg


eg.RegisterPlugin(
    name = "VieraControl",
	description = __doc__,
    author = "Rhys Goodwin",
    version = "0.0.2",
	guid = "{89013fb6-614e-4340-8e98-9b476cc4661f}",
    kind = "external",
	url = "http://blog.rhysgoodwin.com",
	icon ="""
	iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAAAXNSR0IArs4c6QAAAARnQU1BAACx
jwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAu
M4zml1AAAAOdSURBVEhL7VV5SNNhGLa07E6KioqcmuY108JKCwNtqVGg3UIZ/WFhRGQUBUFFBxXd
QkaWJVIW7Z4zt9nK+whLxaupeXY4t9KZbW5z0975/hzz57YyMwh6eP4Ze3/P873H9342/WOMv2VQ
U6/gCD8+4bakcpqtkdv8hNdM57fyRB+ziqSVks42mVKp0up0+r6+PpQigTBIYTYER2V50QTuwRnW
6RGS4RUi8AkVBkSKI/flH7tQlsJsLK/p7OrW6s25EAbxybUuQen2bkw7F8avcMJixiQ3pgOVTQnk
r94sjjlRksJqav2khFRQ0AjC4NaDWkpguq0Tw8aRPiLaOtEnL2EuWJEWHp2T9LRBKu+BPFATYTSo
+z0D5HgKfbYvJzIm70VeW49ah5qIn2QwjkK3d2XM8GLP9ObM8GZP92RDZUCOFAaEVBwD+aeuV3xu
V6EmgjC4aTDgQxDps2meLL9w4Zb9+dtiC4ERMfkhO7O9aYI5ftwJLuTTTHFn0XZlF72VoyZi0CCp
FvyHG7iufX4+vqqsqqOqVlEpUZRXd+a9liUzGvccKR5+IPjptDr94bMG1EQMlijJTAbjHOm+YaJH
rCa1Rgfzh4QewuAXvpFHHSx0oHJM44FQw+MXy1ATYS0DwoA9xABGXa/XS2WqU9cq4BPTeOBUd9b+
EyWoiTDtAbnJpgYYhgCPtnbVySsVi1aRDaZ5sA+fKSXiBkAqEblvXusECSl1UrmqQ6HpUKi/dqpl
X3rqGr/R+S2b9ubCdJHiZ/lwLifUoCbCWg+A85bzth8ouHr3HdTwxn3JtXuSS3dq4s6Whu3Onu+f
Zus85EBwvak0ATOjFTURgwYWxnTiYsZ8fx7Mpc96IZUmhGUFu2jhyrSpHqzxQ4Phcsxdxt179DVs
QNREmBpYvMlw3UxJ+hcJCyMg4gWMnKJLg5oIo8GoVoWdMwNuwJFzpXWNXaR9N1oDSAjODurRccUv
C6QDAz3CZQcSUG4SIRKW9kRXJuy4NVvFF29Xw5Ol0Q68O+YNLEwRNHmBP29pqNAvXIRctkHkvzEz
aKt4R2zBsQvlianv80tkMMcGdcBIDRwD+IdOv+Vlfsh49Ylg1ufM3Lac4nZYUE2t3fIOtVLVi0+m
EaiJsFYiuMkwmomp9aACLyLyW7e2+7v2u6pXrdb1Gg5NKA4oG4CCRhAG8RYMzK4KsyDkx87AEv4b
GEF0YGQ9oNBh8B//EYOxw79u0N//A0lSJcnlzk9DAAAAAElFTkSuQmCC""",
	)

import urllib2



class VieraControl(eg.PluginBase):

	def Configure(
		self,
		TVhost="",
		TVport=55000,
	):
		panel = eg.ConfigPanel()
		hostCtrl = panel.TextCtrl(TVhost)
		portCtrl = panel.SpinIntCtrl(TVport, max=65535)
	

		tcpBox = panel.BoxedGroup(
		"TV IP Settings",
		("Host :", hostCtrl),
		("Port :", portCtrl),
		)
		eg.EqualizeWidths(tcpBox.GetColumnItems(0))

		
		panel.sizer.Add(tcpBox, 0, wx.EXPAND)

		while panel.Affirmed():
			panel.SetResult(
			hostCtrl.GetValue(),
			portCtrl.GetValue(),
		)
		
	def __start__(
		self,
		TVhost="localhost",
		TVport=55000,
	):
		self.TVhost = TVhost
		self.TVport = TVport


	def __init__(self):
		self.AddAction(CH_DOWN)
		self.AddAction(CH_UP)
		self.AddAction(VOLUP)
		self.AddAction(VOLDOWN)
		self.AddAction(MUTE)
		self.AddAction(TV)
		self.AddAction(CHG_INPUT)
		self.AddAction(RED)
		self.AddAction(GREEN)
		self.AddAction(YELLOW)
		self.AddAction(BLUE)
		self.AddAction(VTOOLS)
		self.AddAction(CANCEL)
		self.AddAction(SUBMENU)
		self.AddAction(RETURN)
		self.AddAction(ENTER)
		self.AddAction(RIGHT)
		self.AddAction(LEFT)
		self.AddAction(UP)
		self.AddAction(DOWN)
		self.AddAction(ThreeD)
		self.AddAction(SD_CARD)
		self.AddAction(DISP_MODE)
		self.AddAction(MENU)
		self.AddAction(INTERNET)
		self.AddAction(VIERA_LINK)
		self.AddAction(EPG)
		self.AddAction(TEXT)
		self.AddAction(STTL)
		self.AddAction(INFO)
		self.AddAction(INDEX)
		self.AddAction(HOLD)
		self.AddAction(R_TUNE)
		self.AddAction(POWER)
		self.AddAction(REW)
		self.AddAction(REW)
		self.AddAction(PLAY)
		self.AddAction(FF)
		self.AddAction(SKIP_PREV)
		self.AddAction(PAUSE)
		self.AddAction(SKIP_NEXT)
		self.AddAction(STOP)
		self.AddAction(REC)
		self.AddAction(NUM1)
		self.AddAction(NUM2)
		self.AddAction(NUM3)
		self.AddAction(NUM4)
		self.AddAction(NUM5)
		self.AddAction(NUM6)
		self.AddAction(NUM7)
		self.AddAction(NUM8)
		self.AddAction(NUM9)
		self.AddAction(NUM0)
		self.AddAction(P_NR)
		self.AddAction(OFFTIMER)
		self.AddAction(CHG_NETWORK)
		self.AddAction(CC)
		self.AddAction(SAP)
		self.AddAction(RECLIST)
		self.AddAction(DRIVE)
		self.AddAction(DATA)
		self.AddAction(BD)
		self.AddAction(FAVORITE)
		self.AddAction(DIGA_CTL)
		self.AddAction(VOD)
		self.AddAction(ECO)
		self.AddAction(GAME)
		self.AddAction(EZ_SYNC)
		self.AddAction(PICTAI)
		self.AddAction(MPX)
		self.AddAction(SPLIT)
		self.AddAction(SWAP)
		self.AddAction(R_SCREEN)
		self.AddAction(ThirtyS_SKIP)
		self.AddAction(PROG)
		self.AddAction(TV_MUTE_ON)
		self.AddAction(TV_MUTE_OFF)
		self.AddAction(DMS_CH_UP)
		self.AddAction(DMS_CH_DOWN)
	
	
	def SendCommand(self,cmd):
	
		TVIP = self.TVhost + ":"+ str(self.TVport)
		TVURL = "http://"+TVIP+"/nrc/control_0"
		
		"This sends a command"
		data = (
		'<?xml version="1.0" encoding="utf-8"?>'
		'<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
		'<s:Body>'
		'<u:X_SendKey xmlns:u="urn:panasonic-com:service:p00NetworkControl:1">'
		'<X_KeyEvent>%(cmdstring)s</X_KeyEvent>'
		'</u:X_SendKey>'
		'</s:Body>'
		'</s:Envelope>'
		) % {
		'cmdstring': cmd,
		}
		
		headers = {
			'Host': TVIP,
			'Content-Length': len(data),
			'Content-Type': 'text/xml',
			'SOAPACTION': '"urn:panasonic-com:service:p00NetworkControl:1#X_SendKey"'
		}
		req = urllib2.Request(TVURL, data,headers)

		try:
			response = urllib2.urlopen(req)
			self.TriggerEvent("Target responded with HTTP " +str(response.getcode()))
	
		except:
			print "VieraControl: Failed to connect to TV on "+TVIP 

		
		
		
class CH_DOWN(eg.ActionBase):
	name = "CH_DOWN"
	description = "Channel Down"
	def __call__(self):
		self.plugin.SendCommand("NRC_MUTE-ONOFF")

class CH_UP(eg.ActionBase):
	name = "CH_UP"
	description = "Channel Up"
	def __call__(self):
		self.plugin.SendCommand("NRC_CH_UP-ONOFF")

class VOLUP(eg.ActionBase):
	name = "VOLUP"
	description = "Volume Up"
	def __call__(self):
		self.plugin.SendCommand("NRC_VOLUP-ONOFF")

class VOLDOWN(eg.ActionBase):
	name = "VOLDOWN"
	description = "Volume Down"
	def __call__(self):
		self.plugin.SendCommand("NRC_VOLDOWN-ONOFF")

class name(eg.ActionBase):
	name = "name"
	description = "desc"
	def __call__(self):
		self.plugin.SendCommand("cmd")

class MUTE(eg.ActionBase):
	name = "MUTE"
	description = "Mute"
	def __call__(self):
		self.plugin.SendCommand("NRC_MUTE-ONOFF")

class TV(eg.ActionBase):
	name = "TV"
	description = "TV"
	def __call__(self):
		self.plugin.SendCommand("NRC_TV-ONOFF")

class CHG_INPUT(eg.ActionBase):
	name = "CHG_INPUT"
	description = "Change Input (AV)"
	def __call__(self):
		self.plugin.SendCommand("NRC_CHG_INPUT-ONOFF")

class RED(eg.ActionBase):
	name = "RED"
	description = "Red"
	def __call__(self):
		self.plugin.SendCommand("NRC_RED-ONOFF")

class GREEN(eg.ActionBase):
	name = "GREEN"
	description = "Green"
	def __call__(self):
		self.plugin.SendCommand("NRC_GREEN-ONOFF")

class YELLOW(eg.ActionBase):
	name = "YELLOW"
	description = "Yellow"
	def __call__(self):
		self.plugin.SendCommand("NRC_YELLOW-ONOFF")

class BLUE(eg.ActionBase):
	name = "BLUE"
	description = "Blue"
	def __call__(self):
		self.plugin.SendCommand("NRC_BLUE-ONOFF")

class VTOOLS(eg.ActionBase):
	name = "VTOOLS"
	description = "VIERA tools"
	def __call__(self):
		self.plugin.SendCommand("NRC_VTOOLS-ONOFF")

class CANCEL(eg.ActionBase):
	name = "CANCEL"
	description = "Cancel / Exit"
	def __call__(self):
		self.plugin.SendCommand("NRC_CANCEL-ONOFF")

class SUBMENU(eg.ActionBase):
	name = "SUBMENU"
	description = "Option"
	def __call__(self):
		self.plugin.SendCommand("NRC_SUBMENU-ONOFF")

class RETURN(eg.ActionBase):
	name = "RETURN"
	description = "Return"
	def __call__(self):
		self.plugin.SendCommand("NRC_RETURN-ONOFF")

class ENTER(eg.ActionBase):
	name = "ENTER"
	description = "Control Center click / enter"
	def __call__(self):
		self.plugin.SendCommand("NRC_ENTER-ONOFF")

class RIGHT(eg.ActionBase):
	name = "RIGHT"
	description = "Control Right"
	def __call__(self):
		self.plugin.SendCommand("NRC_RIGHT-ONOFF")

class LEFT(eg.ActionBase):
	name = "LEFT"
	description = "Control Left"
	def __call__(self):
		self.plugin.SendCommand("NRC_LEFT-ONOFF")

class UP(eg.ActionBase):
	name = "UP"
	description = "Control Up"
	def __call__(self):
		self.plugin.SendCommand("NRC_UP-ONOFF")

class DOWN(eg.ActionBase):
	name = "DOWN"
	description = "Control Down"
	def __call__(self):
		self.plugin.SendCommand("NRC_DOWN-ONOFF")

class ThreeD(eg.ActionBase):
	name = "3D"
	description = "3D Button"
	def __call__(self):
		self.plugin.SendCommand("NRC_3D-ONOFF")

class SD_CARD(eg.ActionBase):
	name = "SD_CARD"
	description = "SD Card"
	def __call__(self):
		self.plugin.SendCommand("NRC_SD_CARD-ONOFF")

class DISP_MODE(eg.ActionBase):
	name = "DISP_MODE"
	description = "Display mode / Aspect ratio"
	def __call__(self):
		self.plugin.SendCommand("NRC_DISP_MODE-ONOFF")

class MENU(eg.ActionBase):
	name = "MENU"
	description = "Menu"
	def __call__(self):
		self.plugin.SendCommand("NRC_MENU-ONOFF")

class INTERNET(eg.ActionBase):
	name = "INTERNET"
	description = "VIERA connect"
	def __call__(self):
		self.plugin.SendCommand("NRC_INTERNET-ONOFF")

class VIERA_LINK(eg.ActionBase):
	name = "VIERA_LINK"
	description = "VIERA Link"
	def __call__(self):
		self.plugin.SendCommand("NRC_VIERA_LINK-ONOFF")

class EPG(eg.ActionBase):
	name = "EPG"
	description = "EPG"
	def __call__(self):
		self.plugin.SendCommand("NRC_EPG-ONOFF")

class TEXT(eg.ActionBase):
	name = "TEXT"
	description = "Text / TTV"
	def __call__(self):
		self.plugin.SendCommand("NRC_TEXT-ONOFF")

class STTL(eg.ActionBase):
	name = "STTL"
	description = "STTL / Subtitles"
	def __call__(self):
		self.plugin.SendCommand("NRC_STTL-ONOFF")

class INFO(eg.ActionBase):
	name = "INFO"
	description = "Info"
	def __call__(self):
		self.plugin.SendCommand("NRC_INFO-ONOFF")

class INDEX(eg.ActionBase):
	name = "INDEX"
	description = "TTV index"
	def __call__(self):
		self.plugin.SendCommand("NRC_INDEX-ONOFF")

class HOLD(eg.ActionBase):
	name = "HOLD"
	description = "Image freeze"
	def __call__(self):
		self.plugin.SendCommand("NRC_HOLD-ONOFF")

class R_TUNE(eg.ActionBase):
	name = "R_TUNE"
	description = "Last view"
	def __call__(self):
		self.plugin.SendCommand("NRC_R_TUNE-ONOFF")

class POWER(eg.ActionBase):
	name = "POWER"
	description = "Power off"
	def __call__(self):
		self.plugin.SendCommand("NRC_POWER-ONOFF")

class REW(eg.ActionBase):
	name = "REW"
	description = "Rewind"
	def __call__(self):
		self.plugin.SendCommand("NRC_REW-ONOFF")

class PLAY(eg.ActionBase):
	name = "PLAY"
	description = "Play"
	def __call__(self):
		self.plugin.SendCommand("NRC_PLAY-ONOFF")

class FF(eg.ActionBase):
	name = "FF"
	description = "Fast Forward"
	def __call__(self):
		self.plugin.SendCommand("NRC_FF-ONOFF")

class SKIP_PREV(eg.ActionBase):
	name = "SKIP_PREV"
	description = "Skip Previous"
	def __call__(self):
		self.plugin.SendCommand("NRC_SKIP_PREV-ONOFF")

class PAUSE(eg.ActionBase):
	name = "PAUSE"
	description = "Pause"
	def __call__(self):
		self.plugin.SendCommand("NRC_PAUSE-ONOFF")

class SKIP_NEXT(eg.ActionBase):
	name = "SKIP_NEXT"
	description = "Skip Next"
	def __call__(self):
		self.plugin.SendCommand("NRC_SKIP_NEXT-ONOFF")

class STOP(eg.ActionBase):
	name = "STOP"
	description = "Stop"
	def __call__(self):
		self.plugin.SendCommand("NRC_STOP-ONOFF")

class REC(eg.ActionBase):
	name = "REC"
	description = "Record"
	def __call__(self):
		self.plugin.SendCommand("NRC_REC-ONOFF")

class NUM1(eg.ActionBase):
	name = "NUM1"
	description = "Numeric 01"
	def __call__(self):
		self.plugin.SendCommand("NRC_D1-ONOFF")

class NUM2(eg.ActionBase):
	name = "NUM2"
	description = "Numeric 02"
	def __call__(self):
		self.plugin.SendCommand("NRC_D2-ONOFF")

class NUM3(eg.ActionBase):
	name = "NUM3"
	description = "Numeric 03"
	def __call__(self):
		self.plugin.SendCommand("NRC_D3-ONOFF")

class NUM4(eg.ActionBase):
	name = "NUM4"
	description = "Numeric 04"
	def __call__(self):
		self.plugin.SendCommand("NRC_D4-ONOFF")

class NUM5(eg.ActionBase):
	name = "NUM5"
	description = "Numeric 05"
	def __call__(self):
		self.plugin.SendCommand("NRC_D5-ONOFF")

class NUM6(eg.ActionBase):
	name = "NUM6"
	description = "Numeric 06"
	def __call__(self):
		self.plugin.SendCommand("NRC_D6-ONOFF")

class NUM7(eg.ActionBase):
	name = "NUM7"
	description = "Numeric 07"
	def __call__(self):
		self.plugin.SendCommand("NRC_D7-ONOFF")

class NUM8(eg.ActionBase):
	name = "NUM8"
	description = "Numeric 08"
	def __call__(self):
		self.plugin.SendCommand("NRC_D8-ONOFF")

class NUM9(eg.ActionBase):
	name = "NUM9"
	description = "Numeric 09"
	def __call__(self):
		self.plugin.SendCommand("NRC_D9-ONOFF")

class NUM0(eg.ActionBase):
	name = "NUM0"
	description = "Numeric 0"
	def __call__(self):
		self.plugin.SendCommand("NRC_D0-ONOFF")

class NUM1(eg.ActionBase):
	name = "NUM1"
	description = "Numeric 01"
	def __call__(self):
		self.plugin.SendCommand("NRC_D1-ONOFF")

class P_NR(eg.ActionBase):
	name = "P_NR"
	description = "P-NR (Noise reduction)"
	def __call__(self):
		self.plugin.SendCommand("NRC_P_NR-ONOFF")

class OFFTIMER(eg.ActionBase):
	name = "OFFTIMER"
	description = "Off Timer"
	def __call__(self):
		self.plugin.SendCommand("NRC_OFFTIMER-ONOFF")

class CHG_NETWORK(eg.ActionBase):
	name = "CHG_NETWORK"
	description = "Change Network?"
	def __call__(self):
		self.plugin.SendCommand("NRC_CHG_NETWORK-ONOFF")

class CC(eg.ActionBase):
	name = "CC"
	description = "CC"
	def __call__(self):
		self.plugin.SendCommand("NRC_CC-ONOFF")

class SAP(eg.ActionBase):
	name = "SAP"
	description = "SAP (We all know one)"
	def __call__(self):
		self.plugin.SendCommand("NRC_SAP-ONOFF")

class RECLIST(eg.ActionBase):
	name = "RECLIST"
	description = "RECLIST"
	def __call__(self):
		self.plugin.SendCommand("NRC_RECLIST-ONOFF")

class DRIVE(eg.ActionBase):
	name = "DRIVE"
	description = "DRIVE"
	def __call__(self):
		self.plugin.SendCommand("NRC_DRIVE-ONOFF")

class DATA(eg.ActionBase):
	name = "DATA"
	description = "DATA"
	def __call__(self):
		self.plugin.SendCommand("RC_DATA-ONOFF")

class REW(eg.ActionBase):
	name = "REW"
	description = "Rewind"
	def __call__(self):
		self.plugin.SendCommand("NRC_REW-ONOFF")

class BD(eg.ActionBase):
	name = "BD"
	description = "BD"
	def __call__(self):
		self.plugin.SendCommand("NRC_BD-ONOFF")

class FAVORITE(eg.ActionBase):
	name = "FAVORITE"
	description = "FAVORITE"
	def __call__(self):
		self.plugin.SendCommand("NRC_FAVORITE-ONOFF")

class DIGA_CTL(eg.ActionBase):
	name = "DIGA_CTL"
	description = "DIGA_CTL"
	def __call__(self):
		self.plugin.SendCommand("NRC_DIGA_CTL-ONOFF")

class VOD(eg.ActionBase):
	name = "VOD"
	description = "VOD"
	def __call__(self):
		self.plugin.SendCommand("NRC_VOD-ONOFF")

class ECO(eg.ActionBase):
	name = "ECO"
	description = "ECO"
	def __call__(self):
		self.plugin.SendCommand("NRC_ECO-ONOFF")

class GAME(eg.ActionBase):
	name = "GAME"
	description = "Game Mode"
	def __call__(self):
		self.plugin.SendCommand("NRC_GAME-ONOFF")

class EZ_SYNC(eg.ActionBase):
	name = "EZ_SYNC"
	description = "EZ_SYNC"
	def __call__(self):
		self.plugin.SendCommand("NRC_EZ_SYNC-ONOFF")

class PICTAI(eg.ActionBase):
	name = "PICTAI"
	description = "PICTAI"
	def __call__(self):
		self.plugin.SendCommand("NRC_PICTAI-ONOFF")

class MPX(eg.ActionBase):
	name = "MPX"
	description = "MPX"
	def __call__(self):
		self.plugin.SendCommand("NRC_MPX-ONOFF")

class SPLIT(eg.ActionBase):
	name = "SPLIT"
	description = "SPLIT"
	def __call__(self):
		self.plugin.SendCommand("NRC_SPLIT-ONOFF")

class SWAP(eg.ActionBase):
	name = "SWAP"
	description = "SWAP"
	def __call__(self):
		self.plugin.SendCommand("NRC_SWAP-ONOFF")

class R_SCREEN(eg.ActionBase):
	name = "R_SCREEN"
	description = "R SCREEN"
	def __call__(self):
		self.plugin.SendCommand("NRC_R_SCREEN-ONOFF")

class ThirtyS_SKIP(eg.ActionBase):
	name = "30S_SKIP"
	description = "30S_SKIP"
	def __call__(self):
		self.plugin.SendCommand("NRC_30S_SKIP-ONOFF")

class PROG(eg.ActionBase):
	name = "PROG"
	description = "PROG"
	def __call__(self):
		self.plugin.SendCommand("NRC_PROG-ONOFF")

class TV_MUTE_ON(eg.ActionBase):
	name = "TV_MUTE_ON"
	description = "Mute On"
	def __call__(self):
		self.plugin.SendCommand("NRC_TV_MUTE_ON-ONOFF")

class TV_MUTE_OFF(eg.ActionBase):
	name = "TV_MUTE_OFF"
	description = "Mute Off"
	def __call__(self):
		self.plugin.SendCommand("NRC_TV_MUTE_OFF-ONOFF")

class DMS_CH_UP(eg.ActionBase):
	name = "DMS_CH_UP"
	description = "DMS_CH_UP"
	def __call__(self):
		self.plugin.SendCommand("NRC_DMS_CH_UP-ONOFF")

class DMS_CH_DOWN(eg.ActionBase):
	name = "DMS_CH_DOWN"
	description = "DMS_CH_DOWN"
	def __call__(self):
		self.plugin.SendCommand("NRC_DMS_CH_DOWN-ONOFF")

