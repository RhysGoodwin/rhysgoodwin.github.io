namespace SPDIFKeepAlive
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.rb_out3 = new System.Windows.Forms.RadioButton();
            this.rb_out2 = new System.Windows.Forms.RadioButton();
            this.rb_out1 = new System.Windows.Forms.RadioButton();
            this.rb_out4 = new System.Windows.Forms.RadioButton();
            this.btn_browse = new System.Windows.Forms.Button();
            this.tb_custFile = new System.Windows.Forms.TextBox();
            this.btn_start = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.ll_blog = new System.Windows.Forms.LinkLabel();
            this.gp_info = new System.Windows.Forms.GroupBox();
            this.timer_restartInterval = new System.Windows.Forms.Timer(this.components);
            this.cb_autoRestart = new System.Windows.Forms.CheckBox();
            this.contextMenuStrip1.SuspendLayout();
            this.gp_info.SuspendLayout();
            this.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "SPDIFKeepAlive";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.DoubleClick += new System.EventHandler(this.notifyIcon1_DoubleClick);
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(172, 26);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(171, 22);
            this.toolStripMenuItem1.Text = "Exit SPDIFKeepAlive";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(358, 103);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Save and Hide";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 52);
            this.label1.TabIndex = 2;
            this.label1.Text = "SPDIFKeepAlive continuously plays a wave file to \r\nkeep your receiver initialized" +
                ".\r\n�Rhys Goodwin\r\nv1.2";
            // 
            // rb_out3
            // 
            this.rb_out3.AutoSize = true;
            this.rb_out3.Location = new System.Drawing.Point(11, 55);
            this.rb_out3.Name = "rb_out3";
            this.rb_out3.Size = new System.Drawing.Size(60, 17);
            this.rb_out3.TabIndex = 3;
            this.rb_out3.Text = "Silence";
            this.rb_out3.UseVisualStyleBackColor = true;
            this.rb_out3.CheckedChanged += new System.EventHandler(this.rb_out3_CheckedChanged);
            // 
            // rb_out2
            // 
            this.rb_out2.AutoSize = true;
            this.rb_out2.Location = new System.Drawing.Point(11, 32);
            this.rb_out2.Name = "rb_out2";
            this.rb_out2.Size = new System.Drawing.Size(96, 17);
            this.rb_out2.TabIndex = 3;
            this.rb_out2.Text = "Inaudible Tone";
            this.rb_out2.UseVisualStyleBackColor = true;
            this.rb_out2.CheckedChanged += new System.EventHandler(this.rb_out2_CheckedChanged);
            // 
            // rb_out1
            // 
            this.rb_out1.AutoSize = true;
            this.rb_out1.Checked = true;
            this.rb_out1.Location = new System.Drawing.Point(11, 9);
            this.rb_out1.Name = "rb_out1";
            this.rb_out1.Size = new System.Drawing.Size(74, 17);
            this.rb_out1.TabIndex = 3;
            this.rb_out1.TabStop = true;
            this.rb_out1.Text = "Test Tone";
            this.rb_out1.UseVisualStyleBackColor = true;
            this.rb_out1.CheckedChanged += new System.EventHandler(this.rb_out1_CheckedChanged);
            // 
            // rb_out4
            // 
            this.rb_out4.AutoSize = true;
            this.rb_out4.Location = new System.Drawing.Point(11, 78);
            this.rb_out4.Name = "rb_out4";
            this.rb_out4.Size = new System.Drawing.Size(63, 17);
            this.rb_out4.TabIndex = 3;
            this.rb_out4.Text = "Custom:";
            this.rb_out4.UseVisualStyleBackColor = true;
            this.rb_out4.CheckedChanged += new System.EventHandler(this.rb_out4_CheckedChanged);
            // 
            // btn_browse
            // 
            this.btn_browse.Location = new System.Drawing.Point(384, 75);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(60, 23);
            this.btn_browse.TabIndex = 1;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = true;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            // 
            // tb_custFile
            // 
            this.tb_custFile.Location = new System.Drawing.Point(134, 77);
            this.tb_custFile.Name = "tb_custFile";
            this.tb_custFile.ReadOnly = true;
            this.tb_custFile.Size = new System.Drawing.Size(244, 20);
            this.tb_custFile.TabIndex = 4;
            // 
            // btn_start
            // 
            this.btn_start.Location = new System.Drawing.Point(256, 103);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(45, 23);
            this.btn_start.TabIndex = 1;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.Location = new System.Drawing.Point(307, 103);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(45, 23);
            this.btn_stop.TabIndex = 1;
            this.btn_stop.Text = "Stop";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Wave Files |*.wav";
            // 
            // ll_blog
            // 
            this.ll_blog.AutoSize = true;
            this.ll_blog.Location = new System.Drawing.Point(192, 52);
            this.ll_blog.Name = "ll_blog";
            this.ll_blog.Size = new System.Drawing.Size(112, 13);
            this.ll_blog.TabIndex = 5;
            this.ll_blog.TabStop = true;
            this.ll_blog.Text = "blog.rhysgoodwin.com";
            this.ll_blog.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_blog_LinkClicked);
            // 
            // gp_info
            // 
            this.gp_info.Controls.Add(this.ll_blog);
            this.gp_info.Controls.Add(this.label1);
            this.gp_info.Location = new System.Drawing.Point(134, -2);
            this.gp_info.Name = "gp_info";
            this.gp_info.Size = new System.Drawing.Size(310, 74);
            this.gp_info.TabIndex = 6;
            this.gp_info.TabStop = false;
            // 
            // timer_restartInterval
            // 
            this.timer_restartInterval.Enabled = true;
            this.timer_restartInterval.Interval = 3000;
            this.timer_restartInterval.Tick += new System.EventHandler(this.timer_restartInterval_Tick);
            // 
            // cb_autoRestart
            // 
            this.cb_autoRestart.AutoSize = true;
            this.cb_autoRestart.Location = new System.Drawing.Point(11, 102);
            this.cb_autoRestart.Name = "cb_autoRestart";
            this.cb_autoRestart.Size = new System.Drawing.Size(193, 17);
            this.cb_autoRestart.TabIndex = 7;
            this.cb_autoRestart.Text = "Enable Auto Restart (Experimental!)";
            this.cb_autoRestart.UseVisualStyleBackColor = true;
            this.cb_autoRestart.CheckedChanged += new System.EventHandler(this.cb_autoRestart_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 131);
            this.Controls.Add(this.cb_autoRestart);
            this.Controls.Add(this.gp_info);
            this.Controls.Add(this.tb_custFile);
            this.Controls.Add(this.rb_out1);
            this.Controls.Add(this.rb_out2);
            this.Controls.Add(this.rb_out3);
            this.Controls.Add(this.rb_out4);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_browse);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.ShowInTaskbar = false;
            this.Text = "SPDIFKeepAlive";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.contextMenuStrip1.ResumeLayout(false);
            this.gp_info.ResumeLayout(false);
            this.gp_info.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rb_out3;
        private System.Windows.Forms.RadioButton rb_out2;
        private System.Windows.Forms.RadioButton rb_out1;
        private System.Windows.Forms.RadioButton rb_out4;
        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.TextBox tb_custFile;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.LinkLabel ll_blog;
        private System.Windows.Forms.GroupBox gp_info;
        private System.Windows.Forms.Timer timer_restartInterval;
        private System.Windows.Forms.CheckBox cb_autoRestart;
    }
}

