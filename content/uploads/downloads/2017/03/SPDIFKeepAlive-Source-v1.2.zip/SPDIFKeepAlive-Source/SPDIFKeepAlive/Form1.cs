using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Threading;


namespace SPDIFKeepAlive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        [DllImport("WinMM.dll")]
        public static extern bool PlaySound(byte[] data, IntPtr hMod, UInt32 dwFlags);

        [DllImport("WinMM.dll")]
        public static extern bool PlaySound(string fname, int Mod, UInt32 dwFlags);

        // these are the SoundFlags we are using here, check mmsystem.h for more
        public UInt32 SND_ASYNC = 0x0001; // play asynchronously
        public UInt32 SND_FILENAME = 0x00020000; // use file name
        public UInt32 SND_PURGE = 0x0040; // purge non-static events
        public UInt32 SND_LOOP = 0x0008; // Loop continiously
        public UInt32 SND_MEMORY = 0x0004; //use memory
        public UInt32 SND_NOSTOP = 0x0010; // don't stop any currently playing sound 
        public UInt32 SND_SYNC = 0x0000; /* play synchronously (default) */

        private byte[] _bytes;
        private string _filename;

        private void Form1_Load(object sender, EventArgs e)
        {
            loadSettings();
            Start();
        }

        private void Start()
        {
            if (!rb_out4.Checked)
            {
                string wav = "";
                if (rb_out1.Checked) { wav = "test.wav"; }
                if (rb_out2.Checked) { wav = "inaudible.wav"; }
                if (rb_out3.Checked) { wav = "blank.wav"; }

                // get the namespace
                string strNameSpace = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name.ToString();
                // get the resource into a stream
                Stream str = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(strNameSpace + "." + wav);
                // bring stream into a byte array
                _bytes = new Byte[str.Length];
                str.Read(_bytes, 0, (int)str.Length);
                StartPlayBytes();
            }
            else
            {
                if (File.Exists(tb_custFile.Text)) 
                { 
                    _filename = tb_custFile.Text;
                    StartPlayFile();
                }
            }
            btn_stop.Enabled = true;
            btn_start.Enabled = false;
            TimerStart();
        }
    
        private void StartPlayFile()
        {
            PlaySound(_filename, 0, SND_FILENAME | SND_LOOP | SND_ASYNC | SND_NOSTOP);
        }

  

        private void StartPlayBytes()
        {
            PlaySound(_bytes, IntPtr.Zero, SND_MEMORY | SND_ASYNC | SND_LOOP);
        }

        private void Stop()
        {
            timer_restartInterval.Stop();
            StopPlay();
            btn_stop.Enabled = false;
            btn_start.Enabled = true;
        }

        private void StopPlay()
        {
            byte[] bStr = null;
            //PlaySound(bStr, IntPtr.Zero,SND_ASYNC);
            PlaySound(null, 0, 0);
        }


        private void savesSettings()
        {
            if (rb_out1.Checked) Properties.Settings.Default.outputmode = 1;
            if (rb_out2.Checked) Properties.Settings.Default.outputmode = 2;
            if (rb_out3.Checked) Properties.Settings.Default.outputmode = 3;
            if (rb_out4.Checked) Properties.Settings.Default.outputmode = 4;
            Properties.Settings.Default.custFile = tb_custFile.Text;
            Properties.Settings.Default.autoRestart = cb_autoRestart.Checked;
            Properties.Settings.Default.Save();
        }

        private void loadSettings()
        {
            switch (Properties.Settings.Default.outputmode)
            {
                case 1:
                    rb_out1.Checked = true;
                    break;
                case 2:
                    rb_out2.Checked = true;
                    break;
                case 3:
                    rb_out3.Checked = true;
                    break;
                case 4:
                    rb_out4.Checked = true;
                    break;
            }
            tb_custFile.Text = Properties.Settings.Default.custFile;
            cb_autoRestart.Checked = Properties.Settings.Default.autoRestart;
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
                Hide();
        }

        private void notifyIcon1_DoubleClick(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            this.Focus();
            this.BringToFront();
            this.TopMost = false;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            savesSettings();
            Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            savesSettings();
            Hide();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
             Hide();
        }

        private void rb_out3_CheckedChanged(object sender, EventArgs e)
        {
            Stop();
        }

        private void rb_out2_CheckedChanged(object sender, EventArgs e)
        {
            Stop();
        }

        private void rb_out1_CheckedChanged(object sender, EventArgs e)
        {
            Stop();
        }

        private void rb_out4_CheckedChanged(object sender, EventArgs e)
        {
            Stop();
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            Start();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            Stop();
        }

        private void btn_browse_Click(object sender, EventArgs e)
        {
            Stop();
            rb_out4.Checked = true;
            openFileDialog1.ShowDialog();
            tb_custFile.Text = openFileDialog1.FileName;
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.BringToFront();
        }

        private void ll_blog_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.ProcessStartInfo sInfo = new System.Diagnostics.ProcessStartInfo("http://blog.rhysgoodwin.com");
            System.Diagnostics.Process.Start(sInfo);
        }

        private void TimerStart()
        {
            if (cb_autoRestart.Checked)
            {
                timer_restartInterval.Start();
            }
            else
            {
                timer_restartInterval.Stop();
            }
        }

        private void timer_restartInterval_Tick(object sender, EventArgs e)
        {
            Start();
        }

        private void cb_autoRestart_CheckedChanged(object sender, EventArgs e)
        {
            TimerStart();
        }
    }
}